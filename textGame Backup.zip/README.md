textGame
--------

A simple text adventure game in the command line, using Java.
As of this stage (pre-Alpha), the game is not playable.

--------

To run: Open and run "Game.java" in Eclipse.
It may be possible to run the game in Textpad, or other Java editing software.
